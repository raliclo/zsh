@echo off
setlocal EnableDelayedExpansion
set "ZSH_PORTABLE_DIR=%~dp0"
rem Strip %~dp0's trailing backslash so the value matches the form the
rem native launcher (zsh-loader.exe) uses -- nested sessions compare
rem ZDOTDIR against ZSH_PORTABLE_DIR and must agree regardless of which
rem entry point set them.
if "%ZSH_PORTABLE_DIR:~-1%"=="\" set "ZSH_PORTABLE_DIR=%ZSH_PORTABLE_DIR:~0,-1%"
set "ZSH_WIN_HOME=%USERPROFILE%"
set "ZSH_TERMINFO_DIR=%ZSH_PORTABLE_DIR:\=/%/share/terminfo"
set "ZSH_TERMINFO_DRIVE=%ZSH_TERMINFO_DIR:~0,1%"
set "ZSH_TERMINFO_PATH=%ZSH_TERMINFO_DIR:~2%"
set "TERMINFO=/cygdrive/%ZSH_TERMINFO_DRIVE%%ZSH_TERMINFO_PATH%"
rem "C.utf8" (as in `locale -a`), NOT "C.UTF-8": the dashed spelling is
rem not a real Cygwin locale and is mis-decoded, which scrambles ZLE input.
set "LC_CTYPE=C.utf8"
if not defined LANG set "LANG=C.utf8"

rem Switch the console to UTF-8 (65001) so zsh's UTF-8 output and typed
rem multibyte input round-trip correctly; without this, a console left on
rem a legacy code page (still common unless "Beta: Use Unicode UTF-8" is
rem enabled system-wide) shows mojibake instead of e.g. CJK text or emoji.
rem Save the current code page first and restore it on exit below, so it
rem doesn't leak into the parent cmd/PowerShell session once zsh quits.
for /f "tokens=2 delims=:" %%P in ('chcp') do set "_ZSH_ORIG_CP=%%P"
set "_ZSH_ORIG_CP=%_ZSH_ORIG_CP: =%"
chcp 65001 >nul

rem Prepend the portable dir, then push the Windows system directories to
rem the very end of PATH. Those ship their own find/sort/more/where/... with
rem non-POSIX behavior; left in their normal (early) position they shadow
rem the real tools zsh expects -- e.g. Windows' find.exe instead of the GNU
rem find bundled next to zsh.exe -- no matter what else is on PATH.
set "PATH=%ZSH_PORTABLE_DIR%;%ZSH_PORTABLE_DIR%\usr\bin;%PATH%"
set "_ZSH_SYS32=%SystemRoot%\System32"
set "_ZSH_SYSWOW=%SystemRoot%\SysWOW64"
set "_ZSH_WINDIR=%SystemRoot%"
set "PATH=!PATH:%_ZSH_SYS32%;=!"
set "PATH=!PATH:%_ZSH_SYSWOW%;=!"
set "PATH=!PATH:%_ZSH_WINDIR%;=!"
set "PATH=!PATH!;%_ZSH_SYS32%;%_ZSH_SYSWOW%;%_ZSH_WINDIR%"
set "_ZSH_SYS32="
set "_ZSH_SYSWOW="
set "_ZSH_WINDIR="

rem Precedence for what counts as the user's dot dir (same rules as the
rem native launcher): an explicitly set ZDOTDIR that isn't just the
rem portable dir inherited from an enclosing session wins even when
rem nested; otherwise an inherited ZSH_ORIG_ZDOTDIR is kept (we're
rem nested -- don't clobber the original caller's value); otherwise
rem fall back to USERPROFILE.
if defined ZDOTDIR if /I not "%ZDOTDIR%"=="%ZSH_PORTABLE_DIR%" set "ZSH_ORIG_ZDOTDIR=%ZDOTDIR%"
if not defined ZSH_ORIG_ZDOTDIR set "ZSH_ORIG_ZDOTDIR=%USERPROFILE%"
set "ZDOTDIR=%ZSH_PORTABLE_DIR%"

rem %* is passed through to zsh.exe as-is below; disable delayed expansion
rem first so a literal "!" in a forwarded argument survives untouched.
rem (zsh.exe, not zsh-loader.exe: this script already does the same env setup
rem the native launcher does, so it calls the real interpreter directly.)
setlocal DisableDelayedExpansion
"%ZSH_PORTABLE_DIR%\usr\bin\zsh.exe" %*
set "_ZSH_EXIT=%ERRORLEVEL%"
if defined _ZSH_ORIG_CP chcp %_ZSH_ORIG_CP% >nul
exit /b %_ZSH_EXIT%

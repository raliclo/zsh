zsh_portable_dir=${ZSH_PORTABLE_DIR:-}
zsh_portable_dir_win=
if [[ -n $zsh_portable_dir ]]; then
  zsh_portable_dir=${zsh_portable_dir//\\//}
  zsh_portable_dir=${zsh_portable_dir%/}
  zsh_portable_dir_win=$zsh_portable_dir
  if [[ $zsh_portable_dir == [A-Za-z]:/* ]]; then
    zsh_portable_dir="/cygdrive/${(L)zsh_portable_dir[1]}/${zsh_portable_dir[4,-1]}"
  fi
  module_path=("$zsh_portable_dir" $module_path)
  TERMINFO="$zsh_portable_dir/share/terminfo"
  export TERMINFO
fi
if [[ -n ${ZSH_WIN_HOME:-} ]]; then
  HOME=${ZSH_WIN_HOME//\\//}
  export HOME
fi
if [[ -o interactive ]]; then
  PROMPT="%n@%~%# "
  zsh_portable_fix_keys() {
    local zsh_portable_keymap
    for zsh_portable_keymap in main emacs viins; do
      bindkey -M "$zsh_portable_keymap" "^?" backward-delete-char 2>/dev/null
      bindkey -M "$zsh_portable_keymap" "^H" backward-delete-char 2>/dev/null
    done
    stty erase "^?" 2>/dev/null || stty erase "^H" 2>/dev/null
  }
  precmd_functions=(${precmd_functions:#zsh_portable_fix_keys} zsh_portable_fix_keys)
fi

# ZDOTDIR deliberately stays pointing at the portable dir for the whole
# session tree (ZSH_ORIG_ZDOTDIR/ZSH_PORTABLE_DIR/ZSH_WIN_HOME stay
# exported too): that is what lets a nested zsh.exe, spawned from inside
# this session, find this same bootstrap and load its modules, instead of
# inheriting a consumed, half-restored environment. The user's own
# startup files still run: their .zshenv here, and .zshrc/.zprofile/
# .zlogin via the matching forwarding stubs next to this file -- each
# sourced with ZDOTDIR temporarily set to the user's real dot dir, since
# that is what those files expect it to mean.
if [[ -n ${ZSH_ORIG_ZDOTDIR:-} ]]; then
  zsh_portable_user_zdotdir=${ZSH_ORIG_ZDOTDIR//\\//}
  if [[ $zsh_portable_user_zdotdir != $zsh_portable_dir_win && \
        $zsh_portable_user_zdotdir != $zsh_portable_dir && \
        -r $zsh_portable_user_zdotdir/.zshenv ]]; then
    ZDOTDIR=$zsh_portable_user_zdotdir
    source $zsh_portable_user_zdotdir/.zshenv
    # honor a ZDOTDIR change made by the user's own .zshenv
    if [[ ${ZDOTDIR:-} != $zsh_portable_user_zdotdir ]]; then
      ZSH_ORIG_ZDOTDIR=$ZDOTDIR
      export ZSH_ORIG_ZDOTDIR
    fi
    ZDOTDIR=${ZSH_PORTABLE_DIR:-}
    export ZDOTDIR
  fi
  unset zsh_portable_user_zdotdir
fi
unset zsh_portable_dir zsh_portable_dir_win

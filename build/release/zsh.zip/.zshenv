zsh_portable_dir=${ZSH_PORTABLE_DIR:-}
if [[ -n $zsh_portable_dir ]]; then
  zsh_portable_dir=${zsh_portable_dir//\\//}
  zsh_portable_dir=${zsh_portable_dir%/}
  if [[ $zsh_portable_dir == [A-Za-z]:/* ]]; then
    zsh_portable_dir="/cygdrive/${(L)zsh_portable_dir[1]}/${zsh_portable_dir[4,-1]}"
  fi
  module_path=("$zsh_portable_dir" $module_path)
  TERMINFO="$zsh_portable_dir/share/terminfo"
  export TERMINFO
fi
if [[ -n ${ZSH_WIN_HOME:-} ]]; then
  HOME=${ZSH_WIN_HOME//\\//}
  export HOME
fi
if [[ -o interactive ]]; then
  PROMPT="%n@%~%# "
  zsh_portable_fix_keys() {
    local zsh_portable_keymap
    for zsh_portable_keymap in main emacs viins; do
      bindkey -M "$zsh_portable_keymap" "^?" backward-delete-char 2>/dev/null
      bindkey -M "$zsh_portable_keymap" "^H" backward-delete-char 2>/dev/null
    done
    stty erase "^?" 2>/dev/null || stty erase "^H" 2>/dev/null
  }
  precmd_functions=(${precmd_functions:#zsh_portable_fix_keys} zsh_portable_fix_keys)
fi

if [[ -n ${ZSH_ORIG_ZDOTDIR:-} ]]; then
  zsh_orig_zdotdir=${ZSH_ORIG_ZDOTDIR//\\//}
  ZDOTDIR=$zsh_orig_zdotdir
  export ZDOTDIR
  if [[ $ZDOTDIR != $zsh_portable_dir && -r $ZDOTDIR/.zshenv ]]; then
    source $ZDOTDIR/.zshenv
  fi
  unset ZSH_ORIG_ZDOTDIR ZSH_PORTABLE_DIR ZSH_WIN_HOME zsh_portable_dir zsh_orig_zdotdir
fi

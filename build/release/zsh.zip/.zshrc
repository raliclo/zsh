# Forwarding stub: ZDOTDIR points at the portable runtime dir for the
# whole session (see .zshenv there); this loads the user's real .zshrc
# from their own dot dir, with ZDOTDIR temporarily set the way that
# file expects.
if [[ -n ${ZSH_ORIG_ZDOTDIR:-} ]]; then
  zsh_portable_user_zdotdir=${ZSH_ORIG_ZDOTDIR//\\//}
  if [[ $zsh_portable_user_zdotdir != ${${ZSH_PORTABLE_DIR:-}//\\//} && \
        -r $zsh_portable_user_zdotdir/.zshrc ]]; then
    ZDOTDIR=$zsh_portable_user_zdotdir
    source $zsh_portable_user_zdotdir/.zshrc
    ZDOTDIR=${ZSH_PORTABLE_DIR:-$zsh_portable_user_zdotdir}
    export ZDOTDIR
  fi
  if (( $+functions[zsh_portable_fix_keys] )); then
    zsh_portable_fix_keys
  fi
  unset zsh_portable_user_zdotdir
fi
